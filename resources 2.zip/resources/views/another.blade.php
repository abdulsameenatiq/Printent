<div style="background-color: red;color:aqua;">Hello {{ $productData }}</div>
{{-- <div style="background-color: red;color:aqua;">Hello</div> --}}
